import { ReactCalculator } from "./components/ReactCalculator";

function App() {
  return (
    <div>
      <ReactCalculator />
    </div>
  );
}

export default App;
